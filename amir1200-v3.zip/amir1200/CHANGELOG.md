# Changelog

## 1.0.1
- Fix: gallery images did not load on Windows 11 24H2 (log: "Failed to fetch"). Scene pages and user media are now loaded directly from disk (file://) instead of through virtual host names.
- Log lines for every applied mode and every slide; image errors now include the file URL and error type.
- Fix: WinForms analyzer errors WFO1000/WFO0003 broke the build (1.0.0 first-build fixes).

## 1.0.0
- First release: countdown, live video wallpaper, screenshot gallery.
