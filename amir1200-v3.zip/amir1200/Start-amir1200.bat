@echo off
setlocal
cd /d "%~dp0"
if exist "dist\amir1200\amir1200.exe" (
  start "" "dist\amir1200\amir1200.exe"
  exit /b 0
)
if exist "amir1200.exe" (
  start "" "amir1200.exe"
  exit /b 0
)
echo amir1200 has not been built yet.
echo.
echo Open PowerShell in this folder and run:   .\build\build.ps1
echo (See docs\INSTALL-WINDOWS11.md for step-by-step help.)
echo.
pause
exit /b 1
