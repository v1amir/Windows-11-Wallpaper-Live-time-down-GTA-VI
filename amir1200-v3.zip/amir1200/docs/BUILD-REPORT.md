# Build report

Date of build: 10 October 2026. Environment: Linux sandbox with Node 22 and headless Chromium. **No .NET SDK, no Windows.**

## Final status: IMPLEMENTED, PARTIALLY VERIFIED
Everything requested was written. The browser-side half (scene + control panel) was executed and tested.
The Windows/C# half was **not compiled and not run**, so it may contain compile errors or Windows-specific bugs.

## Executed and passed
| Check | Result |
|---|---|
| Countdown maths (Node, 7 tests): split, rounding up, zero/negative/NaN/Infinity, unit boundaries, large day counts, padding, second alignment | 7 / 7 passed |
| Scene in headless Chromium: four presets render; seconds tick; released state; invalid-date state; bottom/offset/scale placement; overlay hidden when disabled for video | passed (screenshots in `docs/screenshots`) |
| Video in Chromium (VP9 WebM): plays; pause freezes; resume plays; stopping releases the source | passed |
| Gallery in Chromium: slides crossfade (one layer visible); portrait image with "fit" renders | passed |
| Control panel in Chromium with a mock host: edits produce the expected save message; tile guard when no video; drag-reorder and remove messages; file names are inserted as text (no HTML injection) | passed |
| No JavaScript errors in any of the above | passed |
| Syntax: all JS files, all XML (csproj, XAML, manifest); bracket balance of every C# file | passed |

## Written but NOT executed
- **xUnit tests** (`tests/Amir1200.Core.Tests`, about 45 cases: countdown + DST + invalid input, settings round-trip/corruption/clamping, slideshow order/shuffle/repeat/pause-safety, media validation, gallery operations). They are expected to pass but have never run.
- C# compilation of `Amir1200.Core` and `Amir1200.App`.

## Could not be verified at all (needs a real Windows 11 PC)
- Placing the wallpaper **behind desktop icons**, on classic layout and on the 24H2 layout. This is the highest-risk part.
- Clicks passing through to desktop icons.
- WebView2 behaviour inside the desktop layer (rendering, occlusion, video decode with hardware acceleration).
- Multi-monitor, mixed-DPI and display-change handling.
- Tray icon, single-instance behaviour, start-with-Windows registry entry, file/folder dialogs.
- Pause on lock / sleep / full-screen app / battery.
- CPU, GPU and memory use; memory leaks.
- Codec coverage beyond VP9/WebM (H.264 MP4 and MOV were not available in the test browser).
- Light/dark system theme, and scaling at 125/150/200 %.

## Known defects / gaps
- Independent per-monitor wallpapers: not implemented. Light theme: not implemented. Installer: not produced.
- `Serilog` from the plan was replaced by a small built-in logger.
- The countdown release time (00:00 local) is an assumption; the date (19 Nov 2026) comes from press reports, not from Rockstar's own page, which could not be opened in this session.

## How to finish verification (about 15 minutes on your PC)
1. `.\build\build.ps1` (runs the xUnit tests, then builds). Send the first error if there is one.
2. Start amir1200, choose *Countdown*. Check that desktop icons are visible and clickable on top of it.
3. Try Live video and Gallery. Lock the PC and unlock. Open a full-screen game or video.
4. `.\build\Verify-amir1200.ps1` and send the log lines if anything misbehaves.
A GitHub Actions workflow (`.github/workflows/build.yml`) runs the same build and tests on a Windows runner if you host the project on GitHub.
