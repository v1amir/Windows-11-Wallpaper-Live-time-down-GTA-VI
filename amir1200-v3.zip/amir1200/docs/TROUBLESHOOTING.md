# Troubleshooting

| Problem | Likely cause | What to do |
|---|---|---|
| `dotnet` is not recognized | SDK not installed, or PowerShell opened before installing | Install the .NET 10 SDK, then open a **new** PowerShell. |
| `running scripts is disabled` | PowerShell policy | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then run the script again. |
| Build error mentions NuGet / download | No internet or a proxy | Connect and retry. |
| **Build error in C# code** | The C# code has never been compiled by its author | Copy the first `error CS....` line (file and line number) and send it; these are usually one-line fixes. |
| "needs the WebView2 Runtime" | Runtime missing | Install the Evergreen Standalone Installer from https://developer.microsoft.com/microsoft-edge/webview2/ |
| Wallpaper covers desktop icons / shows as a window | Windows refused desktop attachment (message appears in the app) | Exit from the tray. Send the log (Settings > Open log folder). The line `Monitor ...: Attached to ...` shows which method was tried. |
| Wallpaper is black | Video codec unsupported | Convert to H.264 MP4 (e.g. with HandBrake) or WebM. |
| Video has no sound | "Mute" is ticked, or the engine blocked sound | Untick Mute in Live Wallpaper. |
| Wallpaper stops while gaming | "Pause for full-screen apps" | Intended; untick it in Settings to keep playing. |
| Countdown shows the wrong time | Time zone | Set the zone in the Countdown page. The release time is unconfirmed; edit it when the official time is known. |
| Nothing happens when I double-click | Already running (check the tray) | Right-click the tray icon > Open amir1200. |
| Settings look reset | Settings file was damaged | A backup named `settings.json.corrupt-...` is kept in `%LocalAppData%\amir1200`. |

Logs: `%LocalAppData%\amir1200\logs` (kept 7 days, contain no personal data beyond file paths you chose).
Environment check: `.\build\Verify-amir1200.ps1`

## Images or video do not appear (v1.0.1 note)
Version 1.0.0 loaded your files through a virtual web address, which Windows/WebView2 refused on at least one PC
(log line: `This image could not be loaded ... Failed to fetch`). Version 1.0.1 loads the scene and your files straight
from disk instead. If a picture still fails, open the log (Settings > Open log folder). Each slide is now logged
(`Slide: name.jpg`) and each failure names the file and the error type.
