# Using amir1200

## The window
Left: Dashboard, Live Wallpaper, GTA VI Gallery, Countdown, Settings. The green dot at the bottom shows what is running.
Closing the window keeps the wallpaper running in the tray (change this in Settings). Reopen from the tray icon.

## Dashboard
The big preview shows what your desktop shows. The four tiles switch the wallpaper:
**Countdown** (Vice City backdrop + countdown), **Live video**, **Screenshot gallery**, **Off** (back to your normal wallpaper).

## Use a video as your wallpaper
1. **Live Wallpaper** > **Choose video...** and pick an MP4, WebM or MOV file (H.264 MP4 is the safest choice).
2. Press **Set as wallpaper**. It plays behind your icons, looping.
3. Adjust *Fit*, *Mute*, *Volume*, *Loop*, and whether the countdown shows over the video.
4. **Stop and restore** returns to your normal wallpaper. If the file is moved, deleted or its codec is unsupported,
   amir1200 tells you and shows the countdown backdrop instead.

## Use GTA VI screenshots
1. **GTA VI Gallery** > **Add images...** (several at once) or **Add folder...** (includes subfolders, up to 5,000 images).
   Your files stay where they are.
2. Untick a card to skip it; drag cards to reorder; click x to remove one from the gallery (the file is not deleted).
3. Set the interval (default 15 s), shuffle, repeat, fit mode, zoom/pan and crossfade.
4. Press **Start slideshow**. Use Previous / Pause / Next any time.

## Change the release date or the look
**Countdown** page: date and time, time zone, the message shown when the time arrives, layout preset
(Cinematic Center, Minimal Neon, Vice City Sunset, Clean Digital), position, offsets, size, opacity, glow and colors.
Changes appear instantly; nothing needs a restart.

## Settings
Start with Windows (opt-in), keep running in the tray, pause for full-screen apps, pause on battery,
main monitor only, restore previous wallpaper, open the log folder, reset everything.

## Tray menu
Open, switch mode, pause/resume, next image, exit.
