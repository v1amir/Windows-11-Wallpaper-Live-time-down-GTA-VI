using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Amir1200.App.Services;

namespace Amir1200.App;

public partial class App : System.Windows.Application
{
    private const string MutexName = @"Local\amir1200-single-instance";
    private const string ShowEventName = @"Local\amir1200-show";

    private Mutex? _mutex;
    private EventWaitHandle? _showEvent;
    private AppController? _controller;
    private volatile bool _shuttingDown;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        Log.Init();

        _mutex = new Mutex(initiallyOwned: true, MutexName, out bool isFirstInstance);
        if (!isFirstInstance)
        {
            // Another amir1200 is already running: ask it to show its window, then quit.
            try { EventWaitHandle.OpenExisting(ShowEventName).Set(); }
            catch (WaitHandleCannotBeOpenedException) { /* the first instance is still starting */ }
            Shutdown();
            return;
        }

        _showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName);
        var listener = new Thread(WaitForShowRequests) { IsBackground = true, Name = "amir1200-show-listener" };
        listener.Start();

        DispatcherUnhandledException += (_, args) =>
        {
            Log.Error("Unhandled UI exception", args.Exception);
            args.Handled = true; // keep the wallpaper running; the details are in the log
        };
        AppDomain.CurrentDomain.UnhandledException += (_, args) => Log.Error("Unhandled exception", args.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, args) => { Log.Error("Unobserved task exception", args.Exception); args.SetObserved(); };

        try
        {
            _controller = new AppController();
            await _controller.StartAsync(e.Args.Contains("--background"));
        }
        catch (Exception ex)
        {
            Log.Error("amir1200 failed to start", ex);
            MessageBox.Show("amir1200 could not start:\n\n" + ex.Message + "\n\nDetails were written to the log folder:\n" + Log.Folder,
                "amir1200", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }

    private void WaitForShowRequests()
    {
        while (!_shuttingDown && _showEvent is not null)
        {
            try
            {
                if (!_showEvent.WaitOne(1000)) continue;
                Dispatcher.BeginInvoke(new Action(() => { if (_controller is not null) _ = _controller.ShowMainWindowAsync(); }));
            }
            catch (ObjectDisposedException)
            {
                return;
            }
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _shuttingDown = true;
        _controller?.Dispose();
        _showEvent?.Dispose();
        try { _mutex?.ReleaseMutex(); }
        catch (ApplicationException) { /* not owned by this thread */ }
        _mutex?.Dispose();
        base.OnExit(e);
    }
}
