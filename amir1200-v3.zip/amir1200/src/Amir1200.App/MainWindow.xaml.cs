using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interop;
using Amir1200.App.Services;
using Amir1200.App.Wallpaper;
using Microsoft.Web.WebView2.Core;
using WpfWebView2 = Microsoft.Web.WebView2.Wpf.WebView2;

namespace Amir1200.App;

/// <summary>Native shell around the control panel page (ui.html). All state lives in AppController.</summary>
public partial class MainWindow : Window
{
    private readonly WpfWebView2 _web = new();

    public MainWindow()
    {
        InitializeComponent();
        Root.Children.Add(_web);
        SourceInitialized += (_, _) => UseDarkTitleBar();
    }

    internal MediaMapper? Mapper { get; private set; }
    internal event Action<string>? MessageReceived;

    internal async Task InitializeAsync(CoreWebView2Environment env)
    {
        _web.DefaultBackgroundColor = System.Drawing.Color.FromArgb(10, 6, 22);
        await _web.EnsureCoreWebView2Async(env);
        CoreWebView2 core = _web.CoreWebView2;

        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = false;
        core.Settings.AreBrowserAcceleratorKeysEnabled = false;
        core.Settings.IsPasswordAutosaveEnabled = false;
        core.Settings.IsGeneralAutofillEnabled = false;

        // The control panel must never navigate anywhere except its own pages and the user's mapped media.
        core.NavigationStarting += (_, e) =>
        {
            bool allowed = Uri.TryCreate(e.Uri, UriKind.Absolute, out Uri? uri) && uri.IsFile &&
                           uri.LocalPath.StartsWith(AppPaths.SceneDir, StringComparison.OrdinalIgnoreCase);
            if (!allowed) e.Cancel = true;
        };
        core.NewWindowRequested += (_, e) => e.Handled = true;

        Mapper = new MediaMapper();
        core.WebMessageReceived += (_, e) => MessageReceived?.Invoke(e.WebMessageAsJson);
        core.Navigate(AppPaths.SceneUrl("ui.html"));
    }

    internal void Post(string json)
    {
        try { _web.CoreWebView2?.PostWebMessageAsJson(json); }
        catch (InvalidOperationException ex) { Log.Warn("Posting to the control panel failed: " + ex.Message); }
    }

    private void UseDarkTitleBar()
    {
        try
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            int on = 1;
            DwmSetWindowAttribute(hwnd, 20, ref on, sizeof(int)); // DWMWA_USE_IMMERSIVE_DARK_MODE
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException)
        {
            // Cosmetic only.
        }
    }

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
}
