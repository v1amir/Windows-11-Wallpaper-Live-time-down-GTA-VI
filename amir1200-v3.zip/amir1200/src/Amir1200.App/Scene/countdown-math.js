/* Pure countdown helpers. Loaded by scene.html in the browser and by Node for tests. */
(function (root) {
  'use strict';

  /** Splits a remaining time in milliseconds. Never negative; rounds up so 0 means "released". */
  function split(ms) {
    if (!(ms > 0) || !isFinite(ms)) {
      return { released: true, total: 0, days: 0, hours: 0, minutes: 0, seconds: 0 };
    }
    const total = Math.ceil(ms / 1000);
    return {
      released: false,
      total,
      days: Math.floor(total / 86400),
      hours: Math.floor((total % 86400) / 3600),
      minutes: Math.floor((total % 3600) / 60),
      seconds: total % 60,
    };
  }

  /** Zero-pads to at least `min` digits. */
  function pad(n, min) {
    let s = String(Math.max(0, Math.floor(Number(n) || 0)));
    while (s.length < min) s = '0' + s;
    return s;
  }

  /** Milliseconds until the next whole wall-clock second (plus a small safety margin). */
  function msToNextSecond(nowMs) {
    return 1000 - (nowMs % 1000) + 8;
  }

  const api = { split, pad, msToNextSecond };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.A1200 = api;
})(typeof window !== 'undefined' ? window : globalThis);
