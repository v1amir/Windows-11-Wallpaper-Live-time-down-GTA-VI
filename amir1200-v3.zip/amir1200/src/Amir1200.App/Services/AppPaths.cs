using System;
using System.IO;

namespace Amir1200.App.Services;

internal static class AppPaths
{
    public static readonly string DataDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "amir1200");

    public static string SettingsFile => Path.Combine(DataDir, "settings.json");
    public static string LogDir => Path.Combine(DataDir, "logs");
    public static string WebViewData => Path.Combine(DataDir, "webview");
    public static string OriginalWallpaperFile => Path.Combine(DataDir, "original-wallpaper.txt");
    public static string SceneDir => Path.Combine(AppContext.BaseDirectory, "Scene");
    public static string SceneUrl(string file) => new Uri(Path.Combine(SceneDir, file)).AbsoluteUri;
    public static string IconFile => Path.Combine(AppContext.BaseDirectory, "Assets", "amir1200.ico");
}
