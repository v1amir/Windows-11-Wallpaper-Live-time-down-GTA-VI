using System;
using System.IO;

namespace Amir1200.App.Services;

/// <summary>Small file logger. Never throws; never writes secrets (the app has none).</summary>
internal static class Log
{
    private static readonly object Gate = new();

    public static string Folder => AppPaths.LogDir;

    public static void Init()
    {
        try
        {
            Directory.CreateDirectory(Folder);
            foreach (var f in Directory.GetFiles(Folder, "amir1200-*.log"))
            {
                if (File.GetLastWriteTimeUtc(f) < DateTime.UtcNow.AddDays(-7)) File.Delete(f);
            }
        }
        catch (Exception)
        {
            // Logging must never stop the app from starting.
        }
    }

    public static void Info(string message) => Write("INFO", message);
    public static void Warn(string message) => Write("WARN", message);
    public static void Error(string message, Exception? ex = null) =>
        Write("ERROR", ex is null ? message : message + " :: " + ex);

    private static void Write(string level, string message)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(Folder);
                var path = Path.Combine(Folder, $"amir1200-{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(path, $"{DateTime.Now:HH:mm:ss.fff} [{level}] {message}{Environment.NewLine}");
            }
        }
        catch (Exception)
        {
            // Ignore logging failures (disk full, locked file, etc.).
        }
    }
}
