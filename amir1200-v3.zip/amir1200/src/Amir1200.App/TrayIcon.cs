using System;
using System.Drawing;
using System.Windows.Forms;
using Amir1200.App.Services;
using Amir1200.Core;

namespace Amir1200.App;

/// <summary>System tray icon with quick wallpaper switching.</summary>
internal sealed class TrayIcon : IDisposable
{
    private readonly NotifyIcon _icon = new();
    private readonly ToolStripMenuItem _countdown = new("Countdown only");
    private readonly ToolStripMenuItem _video = new("Live video");
    private readonly ToolStripMenuItem _gallery = new("GTA VI gallery");
    private readonly ToolStripMenuItem _off = new("Off (restore desktop)");
    private readonly ToolStripMenuItem _pause = new("Pause wallpaper");
    private readonly ToolStripMenuItem _next = new("Next image");

    public TrayIcon()
    {
        try { _icon.Icon = new Icon(AppPaths.IconFile); }
        catch (Exception ex) when (ex is System.IO.IOException or ArgumentException)
        {
            _icon.Icon = SystemIcons.Application;
        }
        _icon.Text = "amir1200";

        var open = new ToolStripMenuItem("Open amir1200") { Font = new Font(SystemFonts.MenuFont ?? SystemFonts.DefaultFont, FontStyle.Bold) };
        var exit = new ToolStripMenuItem("Exit");
        open.Click += (_, _) => OpenRequested?.Invoke();
        exit.Click += (_, _) => ExitRequested?.Invoke();
        _countdown.Click += (_, _) => ModeRequested?.Invoke(WallpaperMode.CountdownOnly);
        _video.Click += (_, _) => ModeRequested?.Invoke(WallpaperMode.Video);
        _gallery.Click += (_, _) => ModeRequested?.Invoke(WallpaperMode.Gallery);
        _off.Click += (_, _) => ModeRequested?.Invoke(WallpaperMode.Off);
        _pause.Click += (_, _) => TogglePauseRequested?.Invoke();
        _next.Click += (_, _) => NextImageRequested?.Invoke();

        var menu = new ContextMenuStrip();
        menu.Items.AddRange(new ToolStripItem[]
        {
            open, new ToolStripSeparator(),
            _countdown, _video, _gallery, _off, new ToolStripSeparator(),
            _pause, _next, new ToolStripSeparator(), exit,
        });
        _icon.ContextMenuStrip = menu;
        _icon.DoubleClick += (_, _) => OpenRequested?.Invoke();
        _icon.Visible = true;
    }

    public event Action? OpenRequested;
    public event Action<WallpaperMode>? ModeRequested;
    public event Action? TogglePauseRequested;
    public event Action? NextImageRequested;
    public event Action? ExitRequested;

    public void UpdateState(WallpaperMode mode, bool userPaused)
    {
        _countdown.Checked = mode == WallpaperMode.CountdownOnly;
        _video.Checked = mode == WallpaperMode.Video;
        _gallery.Checked = mode == WallpaperMode.Gallery;
        _off.Checked = mode == WallpaperMode.Off;
        _pause.Text = userPaused ? "Resume wallpaper" : "Pause wallpaper";
        _next.Enabled = mode == WallpaperMode.Gallery;
        _icon.Text = "amir1200 - " + mode switch
        {
            WallpaperMode.Video => "live video",
            WallpaperMode.Gallery => "gallery",
            WallpaperMode.CountdownOnly => "countdown",
            _ => "off",
        };
    }

    public void ShowBalloon(string text, bool isError)
    {
        _icon.ShowBalloonTip(5000, "amir1200", text, isError ? ToolTipIcon.Error : ToolTipIcon.Warning);
    }

    public void Dispose()
    {
        _icon.Visible = false;
        _icon.ContextMenuStrip?.Dispose();
        _icon.Dispose();
    }
}
