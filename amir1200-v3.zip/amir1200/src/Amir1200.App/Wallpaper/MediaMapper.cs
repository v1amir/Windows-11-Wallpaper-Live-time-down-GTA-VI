using System;
using System.IO;
using Amir1200.App.Services;

namespace Amir1200.App.Wallpaper;

/// <summary>
/// Turns a user's media file into a URL the scene can load straight from disk (file://), without copying it.
/// The scene pages themselves are loaded from disk too, so the browser engine treats both as local files.
/// </summary>
internal sealed class MediaMapper
{
    /// <summary>Returns a file URL for the file, or null when the file is missing or unreadable.</summary>
    public string? UrlFor(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        try
        {
            string full = Path.GetFullPath(path);
            return File.Exists(full) ? new Uri(full).AbsoluteUri : null;
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException
                                      or IOException or UnauthorizedAccessException or UriFormatException)
        {
            Log.Warn("Media path could not be used: " + ex.Message);
            return null;
        }
    }
}
