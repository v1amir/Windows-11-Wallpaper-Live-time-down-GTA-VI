using System;
using System.Text.Json;
using Amir1200.Core;

namespace Amir1200.App.Wallpaper;

/// <summary>Builds the JSON the scene (scene.js) understands. Countdown math lives in Amir1200.Core and is unit-tested.</summary>
internal static class SceneConfig
{
    private static readonly JsonSerializerOptions Compact = new(JsonDefaults.Options) { WriteIndented = false };

    public static object Build(AppSettings s, WallpaperMode mode, Func<string?, string?> urlFor)
    {
        bool ok = CountdownCalculator.TryGetTargetInstant(s.Countdown.TargetLocal, s.Countdown.TimeZoneId,
            out DateTimeOffset instant, out string? error);

        return new
        {
            mode,
            countdown = new
            {
                valid = ok,
                error,
                targetEpochMs = ok ? instant.ToUnixTimeMilliseconds() : (long?)null,
                finalTitle = s.Countdown.FinalTitle,
                finalSubtitle = s.Countdown.FinalSubtitle,
            },
            overlay = s.Overlay,
            video = new
            {
                url = urlFor(s.Video.Path),
                fit = s.Video.Fit,
                muted = s.Video.Muted,
                volume = s.Video.Volume,
                loop = s.Video.Loop,
            },
            gallery = new
            {
                fit = s.Gallery.Fit,
                kenBurns = s.Gallery.KenBurns,
                crossfadeSeconds = s.Gallery.CrossfadeSeconds,
                intervalSeconds = s.Gallery.IntervalSeconds,
            },
        };
    }

    public static string ToJson(object value) => JsonSerializer.Serialize(value, Compact);

    public static string Message(string type, object payload) =>
        ToJson(new { type, config = payload });
}
