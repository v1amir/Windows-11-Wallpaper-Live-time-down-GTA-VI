using System;
using System.IO;
using System.Linq;
using System.Windows.Threading;
using Amir1200.App.Services;
using Amir1200.Core;

namespace Amir1200.App.Wallpaper;

/// <summary>Runs the slideshow clock. Ordering decisions come from the unit-tested SlideshowEngine.</summary>
internal sealed class SlideshowController : IDisposable
{
    private readonly SlideshowEngine _engine = new();
    private readonly DispatcherTimer _timer = new();
    private bool _running;
    private bool _externalPause;
    private int _consecutiveFailures;
    private string? _lastEmitted;

    public SlideshowController() => _timer.Tick += (_, _) => Advance();

    /// <summary>Raised with the current image path and the next one (for preloading).</summary>
    public event Action<string, string?>? SlideChanged;

    public bool UserPaused { get; private set; }
    public int Count => _engine.Count;
    public string? CurrentPath => _engine.Current;

    public void Configure(GallerySettings gallery)
    {
        _engine.Shuffle = gallery.Shuffle;
        _engine.Repeat = gallery.Repeat;
        _engine.SetItems(GalleryOps.IncludedPaths(gallery).Where(File.Exists));
        _timer.Interval = TimeSpan.FromSeconds(Math.Clamp(gallery.IntervalSeconds, 3, 3600));
        if (_running && _engine.Count == 0) Stop();
        else UpdateTimer();
    }

    /// <summary>Starts the show. Emits the current slide when forced or when it changed since the last emit.</summary>
    public void Start(bool force)
    {
        _running = _engine.Count > 0;
        if (!_running) return;
        _consecutiveFailures = 0;
        if (force || !string.Equals(_engine.Current, _lastEmitted, StringComparison.OrdinalIgnoreCase)) Emit();
        UpdateTimer();
    }

    public void Stop()
    {
        _running = false;
        _lastEmitted = null;
        _timer.Stop();
    }

    public void Next() { if (_running && _engine.MoveNext() is not null) { Emit(); _timer.Stop(); UpdateTimer(); } }
    public void Previous() { if (_running && _engine.MovePrevious() is not null) { Emit(); _timer.Stop(); UpdateTimer(); } }

    public void TogglePause()
    {
        UserPaused = !UserPaused;
        UpdateTimer();
    }

    public void SetExternalPause(bool paused)
    {
        _externalPause = paused;
        UpdateTimer();
    }

    /// <summary>Called when the scene could not load an image. Skips it, but gives up if every image fails.</summary>
    public void ReportBadImage()
    {
        _consecutiveFailures++;
        if (_consecutiveFailures >= Math.Max(1, _engine.Count))
        {
            Log.Error($"Slideshow stopped: {_consecutiveFailures} image(s) in a row could not be loaded.");
            Stop();
            return;
        }
        if (_engine.MoveNext() is not null) Emit();
    }

    public void ReportShown() => _consecutiveFailures = 0;

    private void Advance()
    {
        if (_engine.MoveNext() is null) { _timer.Stop(); return; }
        Emit();
    }

    private void Emit()
    {
        string? current = _engine.Current;
        if (current is null) return;
        _lastEmitted = current;
        SlideChanged?.Invoke(current, _engine.PeekNext());
    }

    private void UpdateTimer()
    {
        if (_running && !UserPaused && !_externalPause && _engine.Count > 1) _timer.Start();
        else _timer.Stop();
    }

    public void Dispose() => _timer.Stop();
}
