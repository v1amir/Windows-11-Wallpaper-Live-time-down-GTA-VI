using System.Text.Json;
using System.Text.Json.Serialization;

namespace Amir1200.Core;

public enum WallpaperMode { Off, Video, Gallery, CountdownOnly }
public enum FitMode { Fill, Fit, Stretch, Crop }
public enum OverlayPreset { CinematicCenter, MinimalNeon, ViceCitySunset, CleanDigital }
public enum OverlayPosition { Top, Center, Bottom, Custom }

public sealed class AppSettings
{
    public int Version { get; set; } = 1;
    public WallpaperMode Mode { get; set; } = WallpaperMode.Off;
    public CountdownSettings Countdown { get; set; } = new();
    public OverlaySettings Overlay { get; set; } = new();
    public VideoSettings Video { get; set; } = new();
    public GallerySettings Gallery { get; set; } = new();
    public BehaviorSettings Behavior { get; set; } = new();
}

public sealed class CountdownSettings
{
    /// <summary>Wall-clock target in the selected time zone, format yyyy-MM-ddTHH:mm.</summary>
    public string TargetLocal { get; set; } = "2026-11-19T00:00";
    /// <summary>"local" or a time zone id (IANA or Windows).</summary>
    public string TimeZoneId { get; set; } = "local";
    public string ReleaseNote { get; set; } =
        "Date announced by Rockstar (via press reports). The exact launch time is not confirmed; edit it here if that changes.";
    public string FinalTitle { get; set; } = "IT'S TIME";
    public string FinalSubtitle { get; set; } = "Grand Theft Auto VI";
}

public sealed class OverlaySettings
{
    public bool Visible { get; set; } = true;
    public OverlayPreset Preset { get; set; } = OverlayPreset.CinematicCenter;
    public OverlayPosition Position { get; set; } = OverlayPosition.Center;
    public double OffsetXPercent { get; set; }
    public double OffsetYPercent { get; set; }
    public double Scale { get; set; } = 1.0;
    public double Opacity { get; set; } = 1.0;
    public double Glow { get; set; } = 1.0;
    public string TextColor { get; set; } = "#ffffff";
    public string AccentPink { get; set; } = "#ff2d95";
    public string AccentCyan { get; set; } = "#18f0ff";
    public bool ShowOnVideo { get; set; } = true;
    public bool ShowOnGallery { get; set; } = true;
}

public sealed class VideoSettings
{
    public string? Path { get; set; }
    public FitMode Fit { get; set; } = FitMode.Fill;
    public bool Muted { get; set; } = true;
    public int Volume { get; set; } = 50;
    public bool Loop { get; set; } = true;
}

public sealed class GalleryImage
{
    public string Path { get; set; } = "";
    public bool Included { get; set; } = true;
}

public sealed class GallerySettings
{
    public List<GalleryImage> Images { get; set; } = new();
    public int IntervalSeconds { get; set; } = 15;
    public bool Shuffle { get; set; }
    public bool Repeat { get; set; } = true;
    public FitMode Fit { get; set; } = FitMode.Fill;
    public bool KenBurns { get; set; } = true;
    public double CrossfadeSeconds { get; set; } = 1.2;
}

public sealed class BehaviorSettings
{
    public bool StartWithWindows { get; set; }
    public bool MinimizeToTray { get; set; } = true;
    public bool PauseOnFullscreen { get; set; } = true;
    public bool PauseOnBattery { get; set; }
    public bool PrimaryMonitorOnly { get; set; }
}

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = Create();

    private static JsonSerializerOptions Create()
    {
        var o = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            PropertyNameCaseInsensitive = true,
        };
        o.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
        return o;
    }
}
