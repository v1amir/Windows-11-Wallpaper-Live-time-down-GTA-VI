namespace Amir1200.Core;

public static class MediaFiles
{
    public static readonly string[] VideoExtensions = { ".mp4", ".webm", ".mov", ".m4v", ".ogv" };
    public static readonly string[] ImageExtensions = { ".jpg", ".jpeg", ".png", ".webp", ".bmp" };

    public static bool IsVideo(string? path) => HasExtension(path, VideoExtensions);
    public static bool IsImage(string? path) => HasExtension(path, ImageExtensions);

    private static bool HasExtension(string? path, string[] allowed)
    {
        if (string.IsNullOrWhiteSpace(path)) return false;
        var ext = Path.GetExtension(path);
        return allowed.Contains(ext, StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>Checks that a video path is usable. Returns a human-readable error, or null when fine.</summary>
    public static string? ValidateVideo(string? path) => Validate(path, IsVideo, "video", VideoExtensions);

    public static string? ValidateImage(string? path) => Validate(path, IsImage, "image", ImageExtensions);

    private static string? Validate(string? path, Func<string?, bool> typeCheck, string kind, string[] extensions)
    {
        if (string.IsNullOrWhiteSpace(path)) return $"No {kind} file is selected.";
        if (!typeCheck(path)) return $"This {kind} format is not supported. Supported: {string.Join(", ", extensions)}.";

        try
        {
            if (!File.Exists(path)) return $"The {kind} file was moved or deleted: {path}";
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            return null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return $"The {kind} file cannot be opened ({ex.Message}).";
        }
    }

    /// <summary>Lists supported images in a folder. Inaccessible subfolders are skipped instead of failing.</summary>
    public static List<string> EnumerateImages(string folder, bool recursive)
    {
        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder)) return new List<string>();

        var options = new EnumerationOptions
        {
            IgnoreInaccessible = true,
            RecurseSubdirectories = recursive,
            MatchCasing = MatchCasing.CaseInsensitive,
        };

        return Directory.EnumerateFiles(folder, "*", options)
            .Where(IsImage)
            .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }
}

public static class GalleryOps
{
    /// <summary>Adds supported images, skipping duplicates. Returns how many were added.</summary>
    public static int AddRange(GallerySettings gallery, IEnumerable<string> paths)
    {
        var known = new HashSet<string>(gallery.Images.Select(i => i.Path), StringComparer.OrdinalIgnoreCase);
        int added = 0;
        foreach (var p in paths)
        {
            if (!MediaFiles.IsImage(p) || !known.Add(p)) continue;
            gallery.Images.Add(new GalleryImage { Path = p, Included = true });
            added++;
        }
        return added;
    }

    public static bool Remove(GallerySettings gallery, string path) =>
        gallery.Images.RemoveAll(i => i.Path.Equals(path, StringComparison.OrdinalIgnoreCase)) > 0;

    public static void SetIncluded(GallerySettings gallery, string path, bool included)
    {
        var item = gallery.Images.FirstOrDefault(i => i.Path.Equals(path, StringComparison.OrdinalIgnoreCase));
        if (item is not null) item.Included = included;
    }

    /// <summary>Moves an item so drag-and-drop order is saved. Out-of-range indexes are ignored.</summary>
    public static bool Move(GallerySettings gallery, int from, int to)
    {
        var list = gallery.Images;
        if (from < 0 || from >= list.Count || to < 0 || to >= list.Count || from == to) return false;
        var item = list[from];
        list.RemoveAt(from);
        list.Insert(to, item);
        return true;
    }

    public static List<string> IncludedPaths(GallerySettings gallery) =>
        gallery.Images.Where(i => i.Included).Select(i => i.Path).ToList();
}
