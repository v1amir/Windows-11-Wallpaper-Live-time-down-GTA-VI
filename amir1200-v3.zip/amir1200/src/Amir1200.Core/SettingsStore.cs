using System.Text.Json;

namespace Amir1200.Core;

public sealed class SettingsStore
{
    private readonly object _gate = new();

    public SettingsStore(string filePath) => FilePath = filePath;

    public string FilePath { get; }

    /// <summary>Loads settings. A missing file gives defaults; a corrupt file is backed up and replaced by defaults.</summary>
    public AppSettings Load(out string? warning)
    {
        warning = null;
        lock (_gate)
        {
            if (!File.Exists(FilePath)) return SettingsValidator.Normalize(new AppSettings());

            try
            {
                var json = File.ReadAllText(FilePath);
                var loaded = JsonSerializer.Deserialize<AppSettings>(json, JsonDefaults.Options);
                return SettingsValidator.Normalize(loaded);
            }
            catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
            {
                warning = $"Settings could not be read ({ex.Message}). Defaults were loaded.";
                TryBackupCorruptFile();
                return SettingsValidator.Normalize(new AppSettings());
            }
        }
    }

    /// <summary>Writes to a temp file first, then swaps it in, so a crash cannot leave a half-written file.</summary>
    public void Save(AppSettings settings)
    {
        lock (_gate)
        {
            SettingsValidator.Normalize(settings);
            var dir = Path.GetDirectoryName(FilePath);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

            var tmp = FilePath + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(settings, JsonDefaults.Options));
            File.Move(tmp, FilePath, overwrite: true);
        }
    }

    private void TryBackupCorruptFile()
    {
        try
        {
            var backup = FilePath + $".corrupt-{DateTime.Now:yyyyMMdd-HHmmss}";
            File.Move(FilePath, backup, overwrite: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Backup is best effort; the defaults will overwrite the file on the next save.
        }
    }
}
