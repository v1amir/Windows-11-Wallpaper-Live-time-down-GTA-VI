using System.Text.RegularExpressions;

namespace Amir1200.Core;

/// <summary>Clamps and repairs settings so a hand-edited or corrupt file can never crash the app.</summary>
public static partial class SettingsValidator
{
    [GeneratedRegex("^#[0-9a-fA-F]{6}$")]
    private static partial Regex HexColor();

    public static AppSettings Normalize(AppSettings? s)
    {
        s ??= new AppSettings();
        s.Countdown ??= new CountdownSettings();
        s.Overlay ??= new OverlaySettings();
        s.Video ??= new VideoSettings();
        s.Gallery ??= new GallerySettings();
        s.Behavior ??= new BehaviorSettings();
        s.Gallery.Images ??= new List<GalleryImage>();

        var d = new CountdownSettings();
        if (string.IsNullOrWhiteSpace(s.Countdown.TargetLocal)) s.Countdown.TargetLocal = d.TargetLocal;
        if (string.IsNullOrWhiteSpace(s.Countdown.TimeZoneId)) s.Countdown.TimeZoneId = "local";
        s.Countdown.ReleaseNote ??= "";
        s.Countdown.FinalTitle = Limit(s.Countdown.FinalTitle, 40, d.FinalTitle);
        s.Countdown.FinalSubtitle = Limit(s.Countdown.FinalSubtitle, 80, d.FinalSubtitle);

        var o = s.Overlay;
        o.OffsetXPercent = Clamp(o.OffsetXPercent, -50, 50);
        o.OffsetYPercent = Clamp(o.OffsetYPercent, -50, 50);
        o.Scale = Clamp(o.Scale, 0.4, 2.5);
        o.Opacity = Clamp(o.Opacity, 0.1, 1);
        o.Glow = Clamp(o.Glow, 0, 2);
        var od = new OverlaySettings();
        o.TextColor = Color(o.TextColor, od.TextColor);
        o.AccentPink = Color(o.AccentPink, od.AccentPink);
        o.AccentCyan = Color(o.AccentCyan, od.AccentCyan);

        s.Video.Volume = Math.Clamp(s.Video.Volume, 0, 100);
        s.Gallery.IntervalSeconds = Math.Clamp(s.Gallery.IntervalSeconds, 3, 3600);
        s.Gallery.CrossfadeSeconds = Clamp(s.Gallery.CrossfadeSeconds, 0, 5);

        s.Gallery.Images = s.Gallery.Images
            .Where(i => i is not null && !string.IsNullOrWhiteSpace(i.Path))
            .GroupBy(i => i.Path, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();
        return s;
    }

    private static double Clamp(double v, double min, double max) =>
        double.IsNaN(v) || double.IsInfinity(v) ? min : Math.Clamp(v, min, max);

    private static string Limit(string? v, int max, string fallback) =>
        string.IsNullOrWhiteSpace(v) ? fallback : (v.Length > max ? v[..max] : v);

    private static string Color(string? v, string fallback) =>
        v is not null && HexColor().IsMatch(v) ? v : fallback;
}
