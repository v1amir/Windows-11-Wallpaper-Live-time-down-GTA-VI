const test = require('node:test');
const assert = require('node:assert/strict');
const { split, pad, msToNextSecond } = require('../../src/Amir1200.App/Scene/countdown-math.js');

test('splits a duration into days, hours, minutes and seconds', () => {
  const ms = ((10 * 24 + 3) * 3600 + 4 * 60 + 5) * 1000;
  assert.deepEqual(split(ms), { released: false, total: 875045, days: 10, hours: 3, minutes: 4, seconds: 5 });
});

test('a partial second rounds up so zero only appears at release', () => {
  assert.equal(split(400).total, 1);
  assert.equal(split(1000).total, 1);
  assert.equal(split(1001).total, 2);
});

test('zero, negative, NaN and Infinity never produce negative or invalid values', () => {
  for (const v of [0, -1, -86400000, NaN, undefined, null, Infinity, -Infinity]) {
    const r = split(v);
    assert.equal(r.released, true, String(v));
    assert.deepEqual([r.total, r.days, r.hours, r.minutes, r.seconds], [0, 0, 0, 0, 0]);
  }
});

test('boundaries between units', () => {
  assert.deepEqual(split(59 * 1000), { released: false, total: 59, days: 0, hours: 0, minutes: 0, seconds: 59 });
  assert.deepEqual(split(60 * 1000), { released: false, total: 60, days: 0, hours: 0, minutes: 1, seconds: 0 });
  assert.deepEqual(split(86400 * 1000), { released: false, total: 86400, days: 1, hours: 0, minutes: 0, seconds: 0 });
});

test('large day counts keep working', () => {
  assert.equal(split(1234 * 86400 * 1000).days, 1234);
  assert.equal(pad(1234, 2), '1234');
});

test('pad zero-fills and sanitises input', () => {
  assert.equal(pad(5, 2), '05');
  assert.equal(pad(0, 2), '00');
  assert.equal(pad(-3, 2), '00');
  assert.equal(pad('x', 2), '00');
  assert.equal(pad(7.9, 2), '07');
});

test('msToNextSecond always lands just after the next whole second', () => {
  for (const now of [0, 1, 500, 999, 1000, 1234567]) {
    const d = msToNextSecond(now);
    assert.ok(d > 0 && d <= 1008, `${now} -> ${d}`);
    assert.equal((now + d) % 1000, 8);
  }
});
